#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fcntl.h"

int main(int argc, char *argv[]) {
  if (argc != 2) {
    fprintf(2, "Usage: touch filename\n");
    exit(1);
  }

  char *filename = argv[1];

  // Try to open the file without creating it
  int fd = open(filename, 0);
  if (fd >= 0) {
    // File already exists
    close(fd);
    fprintf(2, "touch: cannot create '%s': File already exists\n", filename);
    exit(1);
  }

  // File does not exist, try creating it
  fd = open(filename, O_CREATE | O_RDWR);
  if (fd < 0) {
    fprintf(2, "touch: failed to create file '%s'\n", filename);
    exit(1);
  }

  close(fd);
  exit(0);
}
