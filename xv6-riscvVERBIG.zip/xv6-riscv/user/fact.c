#include "kernel/types.h"
#include "kernel/fcntl.h"
#include "user/user.h"
#include "kernel/stat.h"


int main(int argc,char *argv[])
{
  int n1 = atoi(argv[1]);
  int fact = 1;
  if(n1 < 0)
  {
    printf("negative number provided!\n");
    exit(0);
  }
  for(int i=1;i<=n1 && n1 != 0 ;i++)
  {
    fact=fact*i;
  }
  printf("factorial = %d\n",fact);
  exit(0);
}
