#include "kernel/types.h"
#include "user/user.h"

int main() {
  // Switch to priority-based scheduling
  if (set_sched_mode(1) == 0)
    printf("Switched to PRIORITY-based scheduling.\n");
  else
    printf("Failed to set scheduling mode.\n");

  exit(0);
}
