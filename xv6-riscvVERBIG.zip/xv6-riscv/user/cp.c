#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fcntl.h"

#define BUF_SIZE 512

int main(int argc, char *argv[]) {
  int src_fd, dst_fd, n;
  char buf[BUF_SIZE];

  if (argc != 3) {
    fprintf(2, "Usage: cp source destination\n");
    exit(1);
  }

  src_fd = open(argv[1], O_RDONLY);
  if (src_fd < 0) {
    fprintf(2, "cp: cannot open source file '%s'\n", argv[1]);
    exit(1);
  }

  dst_fd = open(argv[2], O_CREATE | O_WRONLY | O_TRUNC);
  if (dst_fd < 0) {
    fprintf(2, "cp: cannot create destination file '%s'\n", argv[2]);
    close(src_fd);
    exit(1);
  }

  while ((n = read(src_fd, buf, sizeof(buf))) > 0) {
    if (write(dst_fd, buf, n) != n) {
      fprintf(2, "cp: write error to '%s'\n", argv[2]);
      close(src_fd);
      close(dst_fd);
      exit(1);
    }
  }

  if (n < 0) {
    fprintf(2, "cp: read error from '%s'\n", argv[1]);
  }

  close(src_fd);
  close(dst_fd);
  exit(0);
}
