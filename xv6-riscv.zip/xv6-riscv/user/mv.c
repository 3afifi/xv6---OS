#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"

int main(int argc, char *argv[]) {
  if (argc != 3) {
    fprintf(2, "Usage: mv source target\n");
    exit(1);
  }

  char *src = argv[1];
  char *dst = argv[2];

  // Try to create a hard link with the new name
  if (link(src, dst) < 0) {
    fprintf(2, "mv: cannot link '%s' to '%s'\n", src, dst);
    exit(1);
  }

  // If link succeeds, remove the old file
  if (unlink(src) < 0) {
    fprintf(2, "mv: warning: could not remove original file '%s'\n", src);
    // Optionally undo the move
    unlink(dst);
    exit(1);
  }

  exit(0);
}
