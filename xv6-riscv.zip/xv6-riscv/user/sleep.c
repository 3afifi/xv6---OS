#include "kernel/types.h"
#include "kernel/fcntl.h"
#include "user/user.h"

int main( int argc,char *argv[])
{
  int x = atoi(argv[1]);
  sleep(x);
  exit(0);
}
