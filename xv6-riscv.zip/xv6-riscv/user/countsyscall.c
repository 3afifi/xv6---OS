#include "kernel/types.h"
#include "user/user.h"

int main() {
  printf("count = %d\n", syscallcount());
  exit(0);
}
