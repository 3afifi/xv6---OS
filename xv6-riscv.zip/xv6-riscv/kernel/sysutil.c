#include "types.h"

extern int kbd_intr_count;

uint64
sys_kbdint(void)
{
  return kbd_intr_count;
}


extern int total_syscalls;

uint64
sys_syscallcount(void)
{
  return total_syscalls;
}
